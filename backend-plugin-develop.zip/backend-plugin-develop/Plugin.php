<?php namespace WILSON\Backend;

use Illuminate\Contracts\Http\Kernel;
use WILSON\Backend\Classes\Middleware\CDNMiddleware;
use WILSON\Backend\Classes\Middleware\Http2Middleware;
use System\Classes\PluginBase;

/**
 * Backend Plugin Information File
 */
class Plugin extends PluginBase
{
    /**
     * Returns information about this plugin.
     *
     * @return array
     */
    public function pluginDetails()
    {
        return [
            'name'        => 'wilson.backend::lang.plugin.name',
            'description' => 'wilson.backend::lang.plugin.description',
            'author'      => 'wilson.backend::lang.plugin.author',
            'homepage'    => 'N/A',
            'icon'        => 'icon-pagelines',
        ];
    }

    public function boot()
    {
        $this->app[Kernel::class]->pushMiddleware(Http2Middleware::class);
        $this->app[Kernel::class]->pushMiddleware(CDNMiddleware::class);
    }

    public function registerPermissions()
    {
        return [
            'wilson.backend.manage_settings' => [
                'tab'   => 'wilson.backend::lang.plugin.name',
                'label' => 'wilson.backend::lang.plugin.manage_settings_permission',
            ],
        ];
    }

    public function registerSettings()
    {
        return [
            'settings' => [
                'label'       => 'wilson.backend::lang.plugin.name',
                'description' => 'wilson.backend::lang.plugin.manage_settings',
                'category'    => 'system::lang.system.categories.cms',
                'icon'        => 'icon-flash',
                'class'       => 'WILSON\Backend\Models\Settings',
                'order'       => 500,
                'keywords'    => 'speedy caching optimization',
                'permissions' => ['wilson.backend.manage_settings'],
            ],
        ];
    }

}
