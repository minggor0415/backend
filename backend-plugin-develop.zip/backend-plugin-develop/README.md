# backend-plugin
Backend portal plugin for October CMS

## Optimizations

Backend provides you with the following optimization options. You can enable and disable them via the backend settings.

* HTTP/2 preloading
* Gzip
* Cache headers
* Domain sharding

## Requirements

Backend currently only works with the *Apache web server* with enabled `htaccess` file support.

Backend makes use of `mod_expires`, `mod_gzip` and `mod_headers`.

$$ Special Thanks
OFFLINE-GmbH and his/her oc-speedy-plugin
