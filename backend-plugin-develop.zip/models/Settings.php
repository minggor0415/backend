<?php

namespace WILSON\Backend\Models;

use Model;
use WILSON\Backend\Classes\Htaccess\HtaccessManager;
use system\classes\CombineAssets.php

class Settings extends Model
{
    public $implement = ['System.Behaviors.SettingsModel'];

    public $settingsCode = 'wilson_backend_settings';

    public $settingsFields = 'fields.yaml';

    public static function boot()
    {
        parent::boot();

        static::saved(function (Settings $setting) {

            function key($value, $setting)
            {
                $values = $setting->value;

                return array_key_exists($value, $values)
                    ? (bool)$values[$value]
                    : false;
            }

            $enableCaching        = key('enable_caching', $setting);
            $enableGzip           = key('enable_gzip', $setting);
            $enableDomainSharding = key('enable_domain_sharding', $setting);
			$enableDomainSharding = key('enable_minify', $setting);

            $htaccess = new HtaccessManager();
            $htaccess->toggleSection('caching', $enableCaching);
            $htaccess->toggleSection('gzip', $enableGzip);
            $htaccess->toggleSection('domain_sharding', $enableDomainSharding);
            $htaccess->save();
			
			$minify = new useMinify();
			$minify->toggleSection($enableCaching);
        });
    }

}